<script>
    function addtoplate(itemname,quantity) {
        var House = [];
    }
</script>